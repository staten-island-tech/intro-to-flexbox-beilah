function getRGB() {
  let r = Math.floor(Math.random() * 256);
  let g = Math.floor(Math.random() * 256);
  let b = Math.floor(Math.random() * 256);
  console.log(r, g, b);
  const box = document.querySelector(".box");
  box.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;
  /* document
    .querySelector(".container")
    .insertAdjacentHTML("afterbegin", `  <h1>${r}, ${g}, ${b}</h1>`); */
  document.querySelector("h1").textContent = `rgb(${r}, ${g}, ${b})`;
}

document.querySelector(".btn").addEventListener("click", function () {
  getRGB();
});
